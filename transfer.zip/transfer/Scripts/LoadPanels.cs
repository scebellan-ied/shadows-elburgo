using System;
using System.Collections.Generic;
using UnityEngine;

public class LoadPanels : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    [SerializeField] private GameObject panel;

    private List<Tuple<Vector3, Quaternion>> panelPositions = new List<Tuple<Vector3, Quaternion>>();
    void Start()
    {
        panelPositions.Add(new Tuple<Vector3, Quaternion>(new Vector3(10, 5, 5), Quaternion.LookRotation(new Vector3(-15, 10, 20))));
        panelPositions.Add(new Tuple<Vector3, Quaternion>(new Vector3(10, 0, 10), Quaternion.LookRotation(new Vector3(-15, 10, 20))));
        foreach (var panelPosition in panelPositions)
        {
            Instantiate(panel, panelPosition.Item1, panelPosition.Item2);
        }
    }
}
